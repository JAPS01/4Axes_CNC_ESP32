#include "ControlPin.h"

namespace Machine {}

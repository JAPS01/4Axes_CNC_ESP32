#include "TestFramework.h"

/* Normally you don't want these: 

Test(PassingTest, TestFrameworkTest) {
    Assert(1 == 1);
}

Test(FailingTest1, TestFrameworkTest) {
    Assert(1 != 1);
}

Test(FailingTest2, TestFrameworkTest) {
    Assert(1 != 1, "Oops");
}

Test(FailingTest3, TestFrameworkTest) {
    throw "oops";
}

*/

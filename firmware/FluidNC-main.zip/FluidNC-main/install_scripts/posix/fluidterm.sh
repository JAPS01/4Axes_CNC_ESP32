#!/bin/sh

if ! . ./tools.sh; then exit 1; fi

run_fluidterm $*

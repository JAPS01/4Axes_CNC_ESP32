The esptool binaries were extracted from official Espressif release files at
https://github.com/espressif/esptool .

#pragma once

class SPIClass {
public:
    void begin(int sck, int miso, int mosi) { /* TODO */
    }
};

extern SPIClass SPI;

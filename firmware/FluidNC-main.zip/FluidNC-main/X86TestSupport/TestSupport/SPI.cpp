#include "SPI.h"

SPIClass SPI;

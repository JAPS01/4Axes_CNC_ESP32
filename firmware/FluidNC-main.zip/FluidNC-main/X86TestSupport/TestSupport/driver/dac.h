#pragma once

#include <cstdint>

void dacWrite(uint8_t pin, uint8_t value);
